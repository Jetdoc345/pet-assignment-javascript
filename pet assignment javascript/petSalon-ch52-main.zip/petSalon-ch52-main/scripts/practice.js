//object literal
let student1 = {
    name:"John Smith",
    age:99,
    isAdmin:false,
    grade1:3.7
}

document.write(student1.isAdmin);